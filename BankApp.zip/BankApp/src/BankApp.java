public class BankApp {

    private String name;
    private int age;
    private double currentBal=0;
    private double deposit=0;
    private double withdrwal=0;


    public BankApp(String name){
        this.name = name;
        System.out.println("Welcome to myBank.com");;
    }

    public void setAge(int age){

        this.age = age;
    }

    public void setCurrentBal(double currentBal){
        this.currentBal = currentBal;
        System.out.println(this.currentBal);//System.exit(0);
    }

    public void setDeposit(int deposit){
        //System.out.println("dada dada");
        this.currentBal = this.currentBal+deposit;
        System.out.println(this.currentBal);

    }

    public void setWithdrwal(int withdrwal)
    {
        this.currentBal = this.currentBal-withdrwal;
    }

    public void userInfo(){
        System.out.println("\nUser name is: "+this.name+
                "\nUser age is: "+this.age
        );
        //System.out.println(currentBal);System.exit(0);
    }

    public void bankInfo(){
        System.out.println("\nBank balance is: "+this.currentBal
        );
    }
}

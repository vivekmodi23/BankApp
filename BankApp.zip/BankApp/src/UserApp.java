import java.util.Scanner;

public class UserApp{
    public static void main(String args[]){

        boolean exit=true;
        int account=0;
        int age=0;
        double bal=0;
        int comm;
        int depoist;
        int withdrwal;
        String name="";
        Scanner in =  new Scanner(System.in);

        System.out.println("Enter your name");
        name = in.next();
        System.out.println("Current balance is");
        bal = in.nextInt();
        System.out.println("Enter your age");
        age = in.nextInt();
        BankApp nameaccount = new BankApp(name);
        nameaccount.setAge(age);
        nameaccount.setCurrentBal(bal);
        while(exit) {

            System.out.println("\n Select Command");

                System.out.println(
                        "\n1: user detail" +
                        "\n2: bank detail" +
                        "\n3: deposit cash" +
                        "\n4: withdral cash"+
                        "\n5: Exit from here"
                );

            comm = in.nextInt();
                switch (comm) {
                    case 1:
                        //System.out.println(bal);
                        nameaccount.userInfo();
                        break;
                    case 2:
                        nameaccount.bankInfo();
                        break;
                    case 3:
                        System.out.println("Enter amount to be deposit");
                        depoist = in.nextInt();
                        nameaccount.setDeposit(depoist);
                        break;
                    case 4:
                        System.out.println("Enter amount to be withdrwal");
                        withdrwal = in.nextInt();
                        nameaccount.setWithdrwal(withdrwal);
                        break;
                    case 5:
                        account=0;
                        exit=false;
                        break;
                    default:

                        System.out.println("Select command from given number only");
                }


        }



    }
}